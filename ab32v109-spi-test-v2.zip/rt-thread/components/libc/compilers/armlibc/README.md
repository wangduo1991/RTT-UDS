# ARMLIB (Keil-MDK) porting for RT-Thread

Please define RT_USING_LIBC and compile RT-Thread with Keil-MDK compiler.



## More Information

https://www.keil.com/support/man/docs/armlib/